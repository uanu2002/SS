from apps import WatermarkSystem2, WatermarkSystem

def main():
    watermark_system = WatermarkSystem2()
    watermark_system.mainloop()

if __name__ == '__main__':
    main()