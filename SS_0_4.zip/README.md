# BUAA-AI-信号与系统

图像水印与篡改检测大作业

小组成员：吴建宇、刘煦东、黄胜泽、吴升





Features：

| Checked            | Feature                |
| ------------------ | ---------------------- |
| :white_check_mark: | 查看分析频域           |
| :white_check_mark: | FFT/DCT频域水印添加    |
| :white_check_mark: | 可追踪（脆弱）水印添加 |
| :white_check_mark: | ELA分析                |
| :white_check_mark: | 基础图像篡改           |
|                    | DeepFake检测           |

