# BUAA-AI-信号与系统

图像水印与篡改检测大作业

:hear_no_evil:小组成员：吴建宇、刘煦东、吴升、黄胜泽

前端框架基于Python库 `Tkinter`

Features：

| Checked            | Feature                |
| ------------------ | ---------------------- |
| :white_check_mark: | 查看分析频域           |
| :white_check_mark: | FFT/DCT频域水印添加    |
| :white_check_mark: | 可追踪（脆弱）水印添加 |
| :white_check_mark: | 盲水印添加（强水印）   |
| :white_check_mark: | ELA分析                |
| :white_check_mark: | 篡改检测/定位          |
| :white_check_mark: | 多种图像篡改           |
| :white_check_mark: | 支持RGB图像            |
| :white_check_mark: | 图像质量评估           |
|                    | DeepFake检测           |

